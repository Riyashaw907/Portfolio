$(document).ready(function(){
	$("#all").css("background-color", "#F05423");

$("#one").show("slow");
$("#two").show("slow");
$("#three").show("slow");
$("#four").show("slow");
$("#five").show("slow");
$("#six").show("slow");

  $("#all").click(function(){
    
  $("#one").show("slow");
$("#two").show("slow");
$("#three").show("slow");
$("#four").show("slow");
$("#five").show("slow");
$("#six").show("slow");


$("#bcard").css("background-color", "#111111");
$("#all").css("background-color", "#F05423");
$("#social").css("background-color", "#111111");
$("#books").css("background-color", "#111111");
  $("flyer").css("background-color", "#111111"); 
   $("#logos").css("background-color", "#111111");

$("#letters").css("background-color", "#111111");
  });
  $("#bcard").click(function(){

$("#one").hide("slow");
$("#two").hide("slow");
$("#three").show("slow");
$("#four").hide("slow");
$("#five").hide("slow");
$("#six").hide("slow");




$("#bcard").css("background-color", "#F05423");
$("#all").css("background-color", "#111111");
$("#social").css("background-color", "#111111");
$("#books").css("background-color", "#111111");
  $("flyer").css("background-color", "#111111"); 
   $("#logos").css("background-color", "#111111");

$("#letters").css("background-color", "#111111");

  });




  





  $("#logos").click(function(){

$("#one").show("slow");
$("#two").hide("slow");
$("#three").hide("slow");
$("#four").hide("slow");
$("#five").hide("slow");
$("#six").hide("slow");




$("#bcard").css("background-color", "#111111");
$("#all").css("background-color", "#111111");
$("#social").css("background-color", "#111111");
$("#books").css("background-color", "#111111");
  $("flyer").css("background-color", "#111111"); 
   $("#logos").css("background-color", "#F05423");

$("#letters").css("background-color", "#111111");

  });





  $("#books").click(function(){

$("#one").hide("slow");
$("#two").hide("slow");
$("#three").hide("slow");
$("#four").show("slow");
$("#five").hide("slow");
$("#six").hide("slow");




$("#bcard").css("background-color", "#111111");
$("#all").css("background-color", "#111111");
$("#social").css("background-color", "#111111");
$("#books").css("background-color", "#F05423");
  $("flyer").css("background-color", "#111111"); 
   $("#logos").css("background-color", "#111111");

$("#letters").css("background-color", "#111111");

  });



  $("#poster").click(function(){

$("#one").hide("slow");
$("#two").show("slow");
$("#three").hide("slow");
$("#four").hide("slow");
$("#five").hide("slow");
$("#six").hide("slow");




$("#bcard").css("background-color", "#111111");
$("#all").css("background-color", "#111111");
$("#social").css("background-color", "#111111");
$("#books").css("background-color", "#111111");
  $("poster").css("background-color", "#F05423"); 
   $("#logos").css("background-color", "#111111");

$("#letters").css("background-color", "#111111");

  });







    $("#letters").click(function(){

$("#one").hide("slow");
$("#two").hide("slow");
$("#three").hide("slow");
$("#four").hide("slow");
$("#five").hide("slow");
$("#six").show("slow");




$("#bcard").css("background-color", "#111111");
$("#all").css("background-color", "#111111");
$("#social").css("background-color", "#111111");
$("#books").css("background-color", "#111111");
  $("flyer").css("background-color", "#111111"); 
   $("#logos").css("background-color", "#111111");

$("#letters").css("background-color", "#F05423");

  });
});